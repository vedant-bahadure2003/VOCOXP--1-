import React from "react";
import LandingPage from "./pages/LandingPage";

const App = () => {
  return <LandingPage />;
};

export default App;

